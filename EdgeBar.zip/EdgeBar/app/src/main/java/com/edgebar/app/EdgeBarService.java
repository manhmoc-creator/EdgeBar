package com.edgebar.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  EdgeBarService — Core Engine                                        ║
 * ║                                                                      ║
 * ║  Cơ chế sống sót trên Lock Screen (giống Bottom Quick Settings):    ║
 * ║  1. WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY            ║
 * ║     → Chỉ AccessibilityService mới được dùng type này               ║
 * ║     → Nằm trên MỌIT thứ kể cả lock screen                          ║
 * ║  2. FLAG_NOT_FOCUSABLE     → không chiếm focus, không ảnh hưởng UI ║
 * ║  3. FLAG_NOT_TOUCH_MODAL   → touch bên ngoài vẫn qua               ║
 * ║  4. FLAG_SHOW_WHEN_LOCKED  → hiển thị trên lock screen              ║
 * ║  5. FLAG_LAYOUT_IN_SCREEN  → fill toàn bộ màn hình (incl. insets)  ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
public class EdgeBarService extends AccessibilityService {

    // ── Singleton ref để MainActivity có thể ping ──────────────────────
    public static EdgeBarService instance;

    // ── Constants ──────────────────────────────────────────────────────
    private static final String PREFS = "edgebar_prefs";

    /** Chiều cao vùng cảm ứng (dp) — người dùng có thể chỉnh */
    private static final int DEFAULT_TRIGGER_HEIGHT_DP = 24;

    /** Ngưỡng swipe tối thiểu (px) */
    private static final int SWIPE_THRESHOLD_PX = 80;

    /** Thời gian long press (ms) */
    private static final long LONG_PRESS_MS = 500;

    /** Thời gian double tap (ms) */
    private static final long DOUBLE_TAP_MS = 280;

    // ── Views & WindowManager ──────────────────────────────────────────
    private WindowManager wm;
    private FrameLayout overlayView;
    private WindowManager.LayoutParams overlayParams;

    // ── Touch tracking ─────────────────────────────────────────────────
    private float downX, downY, lastX, lastY;
    private long downTime;
    private long lastTapTime = 0;
    private boolean isLongPressTriggered = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable longPressRunnable;

    // ── Torch state ────────────────────────────────────────────────────
    private boolean torchOn = false;
    private CameraManager cameraManager;
    private String cameraId;

    // ── Prefs ──────────────────────────────────────────────────────────
    private SharedPreferences prefs;

    // ══════════════════════════════════════════════════════════════════
    //  Lifecycle
    // ══════════════════════════════════════════════════════════════════

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        // Khởi tạo torch
        try {
            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            cameraId = cameraManager.getCameraIdList()[0];
        } catch (Exception e) {
            cameraManager = null;
        }

        createOverlay();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        removeOverlay();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Không cần xử lý event — overlay tự nhận touch
    }

    @Override
    public void onInterrupt() {}

    // ══════════════════════════════════════════════════════════════════
    //  Overlay Creation
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("ClickableViewAccessibility")
    private void createOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Đọc cấu hình từ prefs
        int triggerHeightDp = prefs.getInt("trigger_height_dp", DEFAULT_TRIGGER_HEIGHT_DP);
        String position = prefs.getString("bar_position", "bottom"); // bottom / left / right
        int triggerWidthPercent = prefs.getInt("trigger_width_percent", 100); // % chiều rộng

        // Convert dp → px
        float density = getResources().getDisplayMetrics().density;
        int triggerHeightPx = (int) (triggerHeightDp * density);

        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        int screenW = dm.widthPixels;
        int screenH = dm.heightPixels;

        int barW, barH, gravity;
        switch (position) {
            case "left":
                barW = triggerHeightPx;  // dùng height làm width cho edge
                barH = (int) (screenH * triggerWidthPercent / 100f);
                gravity = Gravity.START | Gravity.CENTER_VERTICAL;
                break;
            case "right":
                barW = triggerHeightPx;
                barH = (int) (screenH * triggerWidthPercent / 100f);
                gravity = Gravity.END | Gravity.CENTER_VERTICAL;
                break;
            default: // bottom
                barW = (int) (screenW * triggerWidthPercent / 100f);
                barH = triggerHeightPx;
                gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
                break;
        }

        // ── WindowManager.LayoutParams với các cờ magic ───────────────
        overlayParams = new WindowManager.LayoutParams(
                barW,
                barH,
                // TYPE_ACCESSIBILITY_OVERLAY: chỉ có từ API 22,
                // và ĐÂY là lý do overlay sống được trên lock screen!
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,

                // Các cờ quan trọng:
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE      // không steal focus
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL  // pass touch ra ngoài
                        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED // sống trên lock screen!
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN // fill màn hình incl. insets
                        | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,

                PixelFormat.TRANSLUCENT
        );
        overlayParams.gravity = gravity;

        // Tạo view trong suốt — chỉ cảm nhận touch, không block UI
        overlayView = new FrameLayout(this);
        overlayView.setBackgroundColor(
                prefs.getBoolean("show_indicator", true)
                        ? 0x33FFFFFF  // trắng mờ 20% để thấy vị trí bar
                        : 0x00000000  // hoàn toàn trong suốt
        );

        // Gắn touch listener
        overlayView.setOnTouchListener(this::onOverlayTouch);

        wm.addView(overlayView, overlayParams);
    }

    private void removeOverlay() {
        if (wm != null && overlayView != null) {
            try { wm.removeView(overlayView); } catch (Exception ignored) {}
            overlayView = null;
        }
    }

    /** Reload overlay khi user thay đổi cấu hình */
    public void reloadOverlay() {
        removeOverlay();
        createOverlay();
    }

    // ══════════════════════════════════════════════════════════════════
    //  Touch / Gesture Detection
    // ══════════════════════════════════════════════════════════════════

    private boolean onOverlayTouch(View v, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getRawX();
                downY = event.getRawY();
                lastX = downX;
                lastY = downY;
                downTime = System.currentTimeMillis();
                isLongPressTriggered = false;

                // Bắt đầu đếm long press
                longPressRunnable = () -> {
                    isLongPressTriggered = true;
                    vibrate(VibrationPattern.LONG_PRESS);
                    executeAction(getAction("long_press"));
                };
                handler.postDelayed(longPressRunnable, LONG_PRESS_MS);
                return true;

            case MotionEvent.ACTION_MOVE:
                lastX = event.getRawX();
                lastY = event.getRawY();
                // Nếu đã di chuyển đủ xa → không phải long press nữa
                if (Math.abs(lastX - downX) > 20 || Math.abs(lastY - downY) > 20) {
                    cancelLongPress();
                }
                return true;

            case MotionEvent.ACTION_UP:
                cancelLongPress();
                if (!isLongPressTriggered) {
                    handleRelease(event.getRawX(), event.getRawY());
                }
                return true;

            case MotionEvent.ACTION_CANCEL:
                cancelLongPress();
                return true;
        }
        return false;
    }

    private void cancelLongPress() {
        if (longPressRunnable != null) {
            handler.removeCallbacks(longPressRunnable);
            longPressRunnable = null;
        }
    }

    private void handleRelease(float upX, float upY) {
        float dx = upX - downX;
        float dy = upY - downY;
        long elapsed = System.currentTimeMillis() - downTime;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);

        if (dist < SWIPE_THRESHOLD_PX) {
            // Tap hoặc double tap
            long now = System.currentTimeMillis();
            if (now - lastTapTime < DOUBLE_TAP_MS) {
                // Double tap
                lastTapTime = 0;
                vibrate(VibrationPattern.DOUBLE_TAP);
                executeAction(getAction("double_tap"));
            } else {
                lastTapTime = now;
                // Chờ xem có double tap không
                handler.postDelayed(() -> {
                    if (System.currentTimeMillis() - lastTapTime >= DOUBLE_TAP_MS - 10) {
                        vibrate(VibrationPattern.TAP);
                        executeAction(getAction("single_tap"));
                    }
                }, DOUBLE_TAP_MS);
            }
        } else {
            // Swipe — xác định hướng
            vibrate(VibrationPattern.SWIPE);
            if (Math.abs(dx) > Math.abs(dy)) {
                // Ngang
                if (dx > 0) executeAction(getAction("swipe_right"));
                else        executeAction(getAction("swipe_left"));
            } else {
                // Dọc
                if (dy > 0) executeAction(getAction("swipe_down"));
                else        executeAction(getAction("swipe_up"));
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  Action Execution
    // ══════════════════════════════════════════════════════════════════

    private String getAction(String gesture) {
        return prefs.getString("action_" + gesture, ActionType.NONE);
    }

    private void executeAction(String action) {
        if (action == null) return;
        switch (action) {
            case ActionType.SCREEN_OFF:
                performScreenOff();
                break;
            case ActionType.TORCH:
                toggleTorch();
                break;
            case ActionType.SECURE_CAMERA:
                openSecureCamera();
                break;
            case ActionType.BACK:
                performGlobalAction(GLOBAL_ACTION_BACK);
                break;
            case ActionType.HOME:
                performGlobalAction(GLOBAL_ACTION_HOME);
                break;
            case ActionType.RECENTS:
                performGlobalAction(GLOBAL_ACTION_RECENTS);
                break;
            case ActionType.NOTIFICATIONS:
                performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
                break;
            case ActionType.QUICK_SETTINGS:
                performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
                break;
            case ActionType.SCREENSHOT:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
                }
                break;
            case ActionType.SPLIT_SCREEN:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN);
                }
                break;
            case ActionType.VOLUME_UP:
                adjustVolume(AudioManager.ADJUST_RAISE);
                break;
            case ActionType.VOLUME_DOWN:
                adjustVolume(AudioManager.ADJUST_LOWER);
                break;
            case ActionType.CUSTOM_INTENT:
                launchCustomIntent();
                break;
            case ActionType.NONE:
            default:
                break;
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  Individual Actions
    // ══════════════════════════════════════════════════════════════════

    /**
     * Tắt màn hình.
     * Cần quyền DEVICE_ADMIN hoặc dùng performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
     * từ API 28+. Với Android 11 thì API 28 ok.
     */
    private void performScreenOff() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
        }
    }

    /** Toggle đèn pin qua CameraManager */
    private void toggleTorch() {
        if (cameraManager == null) return;
        try {
            torchOn = !torchOn;
            cameraManager.setTorchMode(cameraId, torchOn);
        } catch (Exception e) {
            torchOn = false;
        }
    }

    /**
     * Mở Camera an toàn — dùng ACTION_SCREEN_CAMERA_SHOT hoặc
     * MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE.
     * Intent này mở camera trực tiếp từ lock screen mà KHÔNG unlock.
     */
    private void openSecureCamera() {
        try {
            Intent intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE);
            intent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP
            );
            startActivity(intent);
        } catch (Exception e) {
            // Fallback: camera thường
            try {
                Intent intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (Exception ignored) {}
        }
    }

    private void adjustVolume(int direction) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (am != null) {
            am.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    direction,
                    AudioManager.FLAG_SHOW_UI
            );
        }
    }

    /** Khởi chạy custom intent được lưu trong prefs */
    private void launchCustomIntent() {
        String pkg = prefs.getString("custom_intent_pkg", "");
        String cls = prefs.getString("custom_intent_cls", "");
        if (pkg.isEmpty()) return;
        try {
            Intent intent = new Intent();
            if (!cls.isEmpty()) {
                intent.setClassName(pkg, cls);
            } else {
                intent = getPackageManager().getLaunchIntentForPackage(pkg);
                if (intent == null) return;
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception ignored) {}
    }

    // ══════════════════════════════════════════════════════════════════
    //  Haptic Feedback
    // ══════════════════════════════════════════════════════════════════

    private enum VibrationPattern { TAP, DOUBLE_TAP, LONG_PRESS, SWIPE }

    private void vibrate(VibrationPattern pattern) {
        if (!prefs.getBoolean("haptic_enabled", true)) return;
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            VibrationEffect effect;
            switch (pattern) {
                case DOUBLE_TAP:
                    // Hai nhịp ngắn
                    v.vibrate(VibrationEffect.createWaveform(
                            new long[]{0, 30, 60, 30}, -1));
                    return;
                case LONG_PRESS:
                    effect = VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE);
                    break;
                case SWIPE:
                    effect = VibrationEffect.createOneShot(20, 80);
                    break;
                default: // TAP
                    effect = VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE);
                    break;
            }
            v.vibrate(effect);
        } else {
            v.vibrate(30);
        }
    }
}

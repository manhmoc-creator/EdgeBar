package com.edgebar.app;

/**
 * Hằng số cho tất cả action có thể gán vào gesture.
 * Được lưu dưới dạng String trong SharedPreferences.
 */
public final class ActionType {
    public static final String NONE           = "none";
    public static final String SCREEN_OFF     = "screen_off";
    public static final String TORCH          = "torch";
    public static final String SECURE_CAMERA  = "secure_camera";
    public static final String BACK           = "back";
    public static final String HOME           = "home";
    public static final String RECENTS        = "recents";
    public static final String NOTIFICATIONS  = "notifications";
    public static final String QUICK_SETTINGS = "quick_settings";
    public static final String SCREENSHOT     = "screenshot";
    public static final String SPLIT_SCREEN   = "split_screen";
    public static final String VOLUME_UP      = "volume_up";
    public static final String VOLUME_DOWN    = "volume_down";
    public static final String CUSTOM_INTENT  = "custom_intent";

    /** Danh sách hiển thị trong UI (index tương ứng với VALUES) */
    public static final String[] LABELS = {
        "Không làm gì",
        "Tắt màn hình",
        "Bật/Tắt đèn pin",
        "Mở Camera an toàn",
        "Quay lại (Back)",
        "Màn hình chính (Home)",
        "Ứng dụng gần đây",
        "Kéo thông báo",
        "Quick Settings",
        "Chụp màn hình",
        "Chia đôi màn hình",
        "Tăng âm lượng",
        "Giảm âm lượng",
        "Intent tùy chỉnh…"
    };

    public static final String[] VALUES = {
        NONE, SCREEN_OFF, TORCH, SECURE_CAMERA,
        BACK, HOME, RECENTS, NOTIFICATIONS, QUICK_SETTINGS,
        SCREENSHOT, SPLIT_SCREEN,
        VOLUME_UP, VOLUME_DOWN,
        CUSTOM_INTENT
    };

    private ActionType() {}
}

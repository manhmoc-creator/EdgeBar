package com.edgebar.app;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

/**
 * Màn hình cấu hình — cho phép người dùng:
 * 1. Bật/kiểm tra quyền AccessibilityService
 * 2. Chọn vị trí thanh (bottom / left / right)
 * 3. Chỉnh chiều cao/rộng vùng cảm ứng
 * 4. Gán action vào từng gesture
 * 5. Bật/tắt haptic & indicator
 */
public class MainActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private TextView tvServiceStatus;

    // Gesture keys tương ứng với prefs key "action_<gesture>"
    private static final String[] GESTURE_KEYS = {
        "single_tap", "double_tap", "long_press",
        "swipe_up", "swipe_down", "swipe_left", "swipe_right"
    };
    private static final String[] GESTURE_LABELS = {
        "Chạm 1 lần", "Chạm 2 lần", "Giữ lâu",
        "Vuốt lên", "Vuốt xuống", "Vuốt trái", "Vuốt phải"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("edgebar_prefs", Context.MODE_PRIVATE);
        buildUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateServiceStatus();
    }

    // ══════════════════════════════════════════════════════════════════
    //  UI Building (programmatic — không cần layout XML)
    // ══════════════════════════════════════════════════════════════════

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(32));
        root.setBackgroundColor(0xFF121212);

        // ── Title ──────────────────────────────────────────────────────
        TextView title = new TextView(this);
        title.setText("⬛ EdgeBar");
        title.setTextSize(28);
        title.setTextColor(0xFF1A73E8);
        title.setPadding(0, 0, 0, dp(4));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Gesture bar · Lock screen safe");
        subtitle.setTextSize(13);
        subtitle.setTextColor(0xFF888888);
        subtitle.setPadding(0, 0, 0, dp(24));
        root.addView(subtitle);

        // ── Service Status ─────────────────────────────────────────────
        root.addView(sectionHeader("Trạng thái dịch vụ"));
        tvServiceStatus = new TextView(this);
        tvServiceStatus.setTextSize(14);
        tvServiceStatus.setPadding(0, 0, 0, dp(8));
        root.addView(tvServiceStatus);

        Button btnEnable = styledButton("Mở Accessibility Settings", 0xFF1A73E8);
        btnEnable.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(btnEnable);
        root.addView(spacer(dp(24)));

        // ── Position ───────────────────────────────────────────────────
        root.addView(sectionHeader("Vị trí thanh cử chỉ"));
        String[] posLabels = {"Dưới cùng (Bottom)", "Cạnh trái (Left)", "Cạnh phải (Right)"};
        String[] posValues = {"bottom", "left", "right"};
        RadioGroup rgPos = new RadioGroup(this);
        rgPos.setOrientation(LinearLayout.HORIZONTAL);
        String curPos = prefs.getString("bar_position", "bottom");
        for (int i = 0; i < posLabels.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(posLabels[i]);
            rb.setTextColor(0xFFCCCCCC);
            rb.setTextSize(13);
            rb.setTag(posValues[i]);
            rb.setPadding(0, 0, dp(16), 0);
            if (posValues[i].equals(curPos)) rb.setChecked(true);
            rgPos.addView(rb);
        }
        rgPos.setOnCheckedChangeListener((group, id) -> {
            RadioButton rb = group.findViewById(id);
            if (rb != null) save("bar_position", (String) rb.getTag());
            reloadService();
        });
        root.addView(rgPos);
        root.addView(spacer(dp(16)));

        // ── Trigger Height ─────────────────────────────────────────────
        root.addView(sectionHeader("Độ dày vùng cảm ứng (dp)"));
        SeekBar sbHeight = new SeekBar(this);
        sbHeight.setMax(60); // 4 → 64 dp
        int curHeight = prefs.getInt("trigger_height_dp", 24);
        sbHeight.setProgress(curHeight - 4);
        TextView tvHeight = new TextView(this);
        tvHeight.setTextColor(0xFF888888);
        tvHeight.setTextSize(12);
        tvHeight.setText(curHeight + " dp");
        sbHeight.setOnSeekBarChangeListener(new SimpleSeekBarListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean user) {
                int val = prog + 4;
                tvHeight.setText(val + " dp");
                save("trigger_height_dp", val);
                reloadService();
            }
        });
        root.addView(sbHeight);
        root.addView(tvHeight);
        root.addView(spacer(dp(16)));

        // ── Width % ────────────────────────────────────────────────────
        root.addView(sectionHeader("Chiều rộng (% màn hình)"));
        SeekBar sbWidth = new SeekBar(this);
        sbWidth.setMax(90); // 10 → 100 %
        int curWidth = prefs.getInt("trigger_width_percent", 100);
        sbWidth.setProgress(curWidth - 10);
        TextView tvWidth = new TextView(this);
        tvWidth.setTextColor(0xFF888888);
        tvWidth.setTextSize(12);
        tvWidth.setText(curWidth + "%");
        sbWidth.setOnSeekBarChangeListener(new SimpleSeekBarListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean user) {
                int val = prog + 10;
                tvWidth.setText(val + "%");
                save("trigger_width_percent", val);
                reloadService();
            }
        });
        root.addView(sbWidth);
        root.addView(tvWidth);
        root.addView(spacer(dp(24)));

        // ── Gesture → Action Mapping ───────────────────────────────────
        root.addView(sectionHeader("Gán hành động cho cử chỉ"));
        for (int i = 0; i < GESTURE_KEYS.length; i++) {
            root.addView(gestureRow(GESTURE_KEYS[i], GESTURE_LABELS[i]));
        }
        root.addView(spacer(dp(24)));

        // ── Custom Intent ──────────────────────────────────────────────
        root.addView(sectionHeader("Intent tùy chỉnh"));
        EditText etPkg = new EditText(this);
        etPkg.setHint("Package (vd: com.spotify.music)");
        etPkg.setHintTextColor(0xFF555555);
        etPkg.setTextColor(0xFFEEEEEE);
        etPkg.setBackgroundColor(0xFF1E1E1E);
        etPkg.setPadding(dp(12), dp(8), dp(12), dp(8));
        etPkg.setText(prefs.getString("custom_intent_pkg", ""));
        root.addView(etPkg);
        root.addView(spacer(dp(8)));

        Button btnSavePkg = styledButton("Lưu package", 0xFF333333);
        btnSavePkg.setOnClickListener(v -> {
            save("custom_intent_pkg", etPkg.getText().toString().trim());
            Toast.makeText(this, "Đã lưu", Toast.LENGTH_SHORT).show();
        });
        root.addView(btnSavePkg);
        root.addView(spacer(dp(24)));

        // ── Toggles ────────────────────────────────────────────────────
        root.addView(sectionHeader("Tuỳ chọn khác"));
        root.addView(toggleRow("Haptic feedback", "haptic_enabled", true));
        root.addView(toggleRow("Hiện indicator (thanh mờ)", "show_indicator", true));
        root.addView(spacer(dp(24)));

        // ── Reload button ──────────────────────────────────────────────
        Button btnReload = styledButton("🔄  Áp dụng thay đổi", 0xFF1A73E8);
        btnReload.setOnClickListener(v -> {
            reloadService();
            Toast.makeText(this, "Đã reload overlay", Toast.LENGTH_SHORT).show();
        });
        root.addView(btnReload);
        root.addView(spacer(dp(16)));

        // ── ADB hint ──────────────────────────────────────────────────
        TextView tvAdb = new TextView(this);
        tvAdb.setText("💡 Tip: Nếu overlay không hiện trên lock screen, chạy qua ADB:\n" +
                "adb shell settings put secure enabled_accessibility_services " +
                "com.edgebar.app/.EdgeBarService");
        tvAdb.setTextColor(0xFF666666);
        tvAdb.setTextSize(11);
        tvAdb.setPadding(dp(12), dp(12), dp(12), dp(12));
        tvAdb.setBackgroundColor(0xFF1A1A1A);
        root.addView(tvAdb);

        scroll.addView(root);
        setContentView(scroll);
    }

    // ══════════════════════════════════════════════════════════════════
    //  UI Helpers
    // ══════════════════════════════════════════════════════════════════

    private TextView sectionHeader(String text) {
        TextView tv = new TextView(this);
        tv.setText(text.toUpperCase());
        tv.setTextSize(11);
        tv.setTextColor(0xFF1A73E8);
        tv.setLetterSpacing(0.12f);
        tv.setPadding(0, dp(4), 0, dp(8));
        return tv;
    }

    private View spacer(int height) {
        View v = new View(this);
        v.setMinimumHeight(height);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, height);
        v.setLayoutParams(lp);
        return v;
    }

    private Button styledButton(String label, int bgColor) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextColor(0xFFFFFFFF);
        btn.setBackgroundColor(bgColor);
        btn.setPadding(dp(16), dp(10), dp(16), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(4);
        btn.setLayoutParams(lp);
        return btn;
    }

    /** Một hàng: label gesture + spinner chọn action */
    private LinearLayout gestureRow(String gestureKey, String gestureLabel) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(4), 0, dp(4));

        TextView label = new TextView(this);
        label.setText(gestureLabel);
        label.setTextColor(0xFFCCCCCC);
        label.setTextSize(14);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        label.setLayoutParams(llp);
        row.addView(label);

        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, ActionType.LABELS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // Set current selection
        String curAction = prefs.getString("action_" + gestureKey, ActionType.NONE);
        for (int i = 0; i < ActionType.VALUES.length; i++) {
            if (ActionType.VALUES[i].equals(curAction)) { spinner.setSelection(i); break; }
        }
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, android.view.View v, int pos, long id) {
                save("action_" + gestureKey, ActionType.VALUES[pos]);
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        spinner.setLayoutParams(slp);
        row.addView(spinner);
        return row;
    }

    /** Toggle switch hàng */
    private LinearLayout toggleRow(String label, String prefKey, boolean defaultVal) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(0xFFCCCCCC);
        tv.setTextSize(14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tv.setLayoutParams(lp);
        row.addView(tv);

        Switch sw = new Switch(this);
        sw.setChecked(prefs.getBoolean(prefKey, defaultVal));
        sw.setOnCheckedChangeListener((b, checked) -> {
            prefs.edit().putBoolean(prefKey, checked).apply();
            reloadService();
        });
        row.addView(sw);
        return row;
    }

    private void updateServiceStatus() {
        boolean enabled = isAccessibilityEnabled();
        if (tvServiceStatus != null) {
            if (enabled) {
                tvServiceStatus.setText("✅ EdgeBarService đang chạy");
                tvServiceStatus.setTextColor(0xFF4CAF50);
            } else {
                tvServiceStatus.setText("❌ Chưa bật AccessibilityService — nhấn nút bên dưới");
                tvServiceStatus.setTextColor(0xFFFF5252);
            }
        }
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> list = am.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : list) {
            if (info.getId().contains(getPackageName())) return true;
        }
        return false;
    }

    private void reloadService() {
        if (EdgeBarService.instance != null) {
            EdgeBarService.instance.reloadOverlay();
        }
    }

    private void save(String key, String val) { prefs.edit().putString(key, val).apply(); }
    private void save(String key, int val)    { prefs.edit().putInt(key, val).apply(); }

    private int dp(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    // ══════════════════════════════════════════════════════════════════
    //  SeekBar helper
    // ══════════════════════════════════════════════════════════════════
    private abstract static class SimpleSeekBarListener implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar s) {}
        @Override public void onStopTrackingTouch(SeekBar s) {}
    }
}

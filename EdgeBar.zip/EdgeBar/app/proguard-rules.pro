# EdgeBar ProGuard rules
# Giữ AccessibilityService và các class quan trọng
-keep class com.edgebar.app.EdgeBarService { *; }
-keep class com.edgebar.app.MainActivity { *; }
-keep class com.edgebar.app.BootReceiver { *; }
-keep class com.edgebar.app.ActionType { *; }

# Giữ nguyên tên class cho reflection
-keepnames class com.edgebar.app.**
